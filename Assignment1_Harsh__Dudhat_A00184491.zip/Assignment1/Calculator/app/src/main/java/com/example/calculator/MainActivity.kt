package com.example.calculator

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var tvResult: TextView
    private var operand1 = ""
    private var operand2 = ""
    private var operator = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvResult = findViewById(R.id.tvResult)

        val btnClear = findViewById<Button>(R.id.btnClear)
        val btnDivide = findViewById<Button>(R.id.btnDivide)
        val btnMultiply = findViewById<Button>(R.id.btnMultiply)
        val btnSubtract = findViewById<Button>(R.id.btnSubtract)
        val btnAdd = findViewById<Button>(R.id.btnAdd)
        val btnEquals = findViewById<Button>(R.id.btnEquals)
        val btnDot = findViewById<Button>(R.id.btnDot)

        val numberButtons = arrayOf(
            findViewById(R.id.btn0),
            findViewById<Button>(R.id.btn1),
            findViewById<Button>(R.id.btn2),
            findViewById<Button>(R.id.btn3),
            findViewById<Button>(R.id.btn4),
            findViewById<Button>(R.id.btn5),
            findViewById<Button>(R.id.btn6),
            findViewById<Button>(R.id.btn7),
            findViewById<Button>(R.id.btn8),
            findViewById<Button>(R.id.btn9)
        )

        btnClear.setOnClickListener { clear() }
        btnDivide.setOnClickListener { setOperator("÷") }
        btnMultiply.setOnClickListener { setOperator("×") }
        btnSubtract.setOnClickListener { setOperator("-") }
        btnAdd.setOnClickListener { setOperator("+") }
        btnEquals.setOnClickListener { calculate() }
        btnDot.setOnClickListener { appendDot() }

        for (button in numberButtons) {
            button.setOnClickListener { appendNumber(button.text.toString()) }
        }
    }

    private fun appendNumber(number: String) {
        if (operator.isEmpty()) {
            operand1 += number
            tvResult.text = operand1
        } else {
            operand2 += number
            tvResult.text = operand2
        }
    }

    private fun appendDot() {
        if (operator.isEmpty()) {
            if (!operand1.contains(".")) {
                operand1 += "."
                tvResult.text = operand1
            }
        } else {
            if (!operand2.contains(".")) {
                operand2 += "."
                tvResult.text = operand2
            }
        }
    }

    private fun setOperator(op: String) {
        if (operand1.isNotEmpty() && operator.isEmpty()) {
            operator = op
            tvResult.text = op
        }
    }

    private fun clear() {
        operand1 = ""
        operand2 = ""
        operator = ""
        tvResult.text = "0"
    }

    private fun calculate() {
        if (operand1.isNotEmpty() && operand2.isNotEmpty() && operator.isNotEmpty()) {
            val num1 = operand1.toDouble()
            val num2 = operand2.toDouble()
            val result = when (operator) {
                "+" -> num1 + num2
                "-" -> num1 - num2
                "×" -> num1 * num2
                "÷" -> {
                    if (num2 != 0.0) {
                        num1 / num2
                    } else {
                        // Handle division by zero
                        Double.NaN
                    }
                }
                else -> 0.0
            }
            tvResult.text = result.toString()
            operand1 = result.toString()
            operand2 = ""
            operator = ""
        }
    }
}
