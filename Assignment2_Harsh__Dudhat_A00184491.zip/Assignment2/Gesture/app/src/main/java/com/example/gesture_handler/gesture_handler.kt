package com.example.gesture_handler

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.GestureDetector
import android.view.MotionEvent
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.abs

class MainActivity : AppCompatActivity() {

    private lateinit var gestureDetector: GestureDetector

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main_activity)

        val gestureButton: Button = findViewById(R.id.gestureButton)
        gestureDetector = GestureDetector(this, GestureListener())

        gestureButton.setOnTouchListener { _, event ->
            gestureDetector.onTouchEvent(event)
            true
        }
    }

    inner class GestureListener : GestureDetector.SimpleOnGestureListener() {
        override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
            Toast.makeText(applicationContext, "Single Click!!!", Toast.LENGTH_SHORT).show()
            return true
        }

        override fun onDoubleTap(e: MotionEvent): Boolean {
            Toast.makeText(applicationContext, "Double Click!!!", Toast.LENGTH_SHORT).show()
            return true
        }

        override fun onLongPress(e: MotionEvent) {
            Toast.makeText(applicationContext, "Button Pressed for long time!!!", Toast.LENGTH_SHORT).show()
        }

        override fun onFling(
            e1: MotionEvent?,
            e2: MotionEvent,
            velocityX: Float,
            velocityY: Float
        ): Boolean {
            val deltaX = e2.x - (e1?.x ?: 0f)
            val deltaY = e2.y - (e1?.y ?: 0f)
            if (abs(deltaX) > abs(deltaY)) {
                if (deltaX > 0) {
                    Toast.makeText(applicationContext, "Swipe Right Gesture Detected", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(applicationContext, "Swipe Left Gesture Detected", Toast.LENGTH_SHORT).show()
                }
            } else {
                if (deltaY > 0) {
                    Toast.makeText(applicationContext, "Swipe Down Gesture Detected", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(applicationContext, "Swipe Up Gesture Detected", Toast.LENGTH_SHORT).show()
                }
            }
            return true
        }
    }
}